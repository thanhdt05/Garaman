# Ánh xạ hàm triển khai hiện có

Cập nhật 19/10/2026. Chỉ hai module theo `ke-hoach/00_PHAM_VI.md`. Tên hàm dưới đây trích từ mã nguồn Java; không tạo thêm hàm nghiệp vụ chỉ vì tài liệu cũ từng ghi tên khác. Các getter/setter, Filter và Util phục vụ kỹ thuật, không tạo thêm nút hoặc use case. Báo cáo Word gốc giữ nguyên.

Luồng: tra cứu → chi tiết → quay lại giữ từ khóa/bộ lọc; kho → chọn/thêm NCC → hóa đơn nháp → chọn/thêm phụ tùng → xác nhận trực tiếp → chứng từ → in/ghi nhận trả đủ tiền. Thêm phụ tùng mới quay về để chủ động chọn, không tự thêm dòng.

Các route giữ nguyên tại `app/src/main/webapp/WEB-INF/web.xml`. Hai vị trí Thêm phụ tùng mới gửi POST `/warehouse/purchases/update` với `dichDen=new-part`; `capNhatDongNhap` lưu các ô trước khi chuyển form. Các POST nháp dùng `maYeuCau`, `draftVersion`, `csrfToken` ẩn. Không thêm endpoint.

## controller/AuthServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init() throws ServletException` | public |
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void hienThiDangNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void dangNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void dangXuat(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |

## controller/CatalogServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init() throws ServletException` | public |
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void hienThiTimKiem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void timKiem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void xemChiTiet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |

## controller/HomeServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void hienThiTrangChu(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |

## controller/PurchaseInvoiceServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init() throws ServletException` | public |
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void batDauNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void hienThiBanNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void timPhuTung(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void themDongNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void capNhatDongNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void xoaDongNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void huyBanNhap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void xacNhanHoaDon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void xemHoaDon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void inHoaDon(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void ghiNhanThanhToan(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void hienThiHoaDonChuaThanhToan(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `private boolean kiemTraVersionVaDongThoi(HttpServletRequest req, HttpSession session, String maYeuCau, HttpServletResponse res) throws IOException` | private |
| `private void luuDuLieuDongVaoDraft(HttpServletRequest req, HttpSession session, String maYeuCau)` | private |

## controller/SparePartServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init() throws ServletException` | public |
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void hienThiThemPhuTung(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void themPhuTung(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |

## controller/SupplierServlet4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init() throws ServletException` | public |
| `protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | protected |
| `public void hienThiChonNhaCungCap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void timNhaCungCap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void hienThiThemNhaCungCap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |
| `public void themNhaCungCap(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException` | public |

## dao/DAO.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `private static synchronized void loadConfiguration()` | private |
| `protected Connection getConnection() throws SQLException` | protected |
| `protected String taoMauTimKiem(String tuKhoa)` | protected |

## dao/MemberDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public Member4 timTheoTenDangNhap(String tenDangNhap) throws SQLException` | public |
| `public Member4 layThanhVienDangHoatDong(int id) throws SQLException` | public |
| `private Member4 mapMember(ResultSet rs) throws SQLException` | private |

## dao/PurchaseInvoiceDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public Integer timIdTheoMaYeuCau(String maYeuCau, int idNhanVienKho) throws SQLException` | public |
| `public int luuHoaDonNhap(PurchaseInvoice4 hoaDon) throws SQLException, ValidationException4` | public |
| `public PurchaseInvoice4 layThongTinHoaDonNhap(int id) throws SQLException` | public |
| `public List<PurchaseInvoice4> layHoaDonChuaThanhToan(int idNhanVienKho) throws SQLException` | public |
| `public boolean ghiNhanThanhToan(int idHoaDon, BigDecimal soTienDaTra, int idNhanVienHienTai) throws SQLException, ValidationException4` | public |
| `private int chenHoaDon(Connection con, PurchaseInvoice4 hoaDon) throws SQLException` | private |
| `private void chenChiTiet(Connection con, int idHoaDon, List<PurchaseInvoiceDetail4> chiTiet) throws SQLException` | private |
| `private List<PurchaseInvoiceDetail4> layChiTiet(Connection con, int idHoaDon) throws SQLException` | private |
| `private PurchaseInvoice4 mapInvoice(ResultSet rs) throws SQLException` | private |

## dao/ServiceDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public List<Service4> timDichVuTheoTen(String tuKhoa) throws SQLException` | public |
| `public Service4 layChiTietDichVu(int id) throws SQLException` | public |
| `private Service4 mapService(ResultSet rs) throws SQLException` | private |

## dao/SparePartCategoryDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public List<SparePartCategory4> layDanhSachNhom() throws SQLException` | public |
| `public SparePartCategory4 layNhomDangSuDung(int id) throws SQLException` | public |
| `private SparePartCategory4 mapCategory(ResultSet rs) throws SQLException` | private |

## dao/SparePartDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public List<SparePart4> timPhuTungTheoTen(String tuKhoa, boolean chiCongBo) throws SQLException` | public |
| `public SparePart4 layChiTietPhuTung(int id, boolean chiCongBo) throws SQLException` | public |
| `public BigDecimal layTonKho(int id) throws SQLException` | public |
| `void tangTonSauNhap(Connection con, int idPhuTung, BigDecimal soLuong) throws SQLException, ValidationException4` | package-private (`~`) |
| `public int themPhuTung(SparePart4 part) throws SQLException, ValidationException4` | public |
| `private SparePart4 mapSparePart(ResultSet rs) throws SQLException` | private |

## dao/SupplierDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public List<Supplier4> timNhaCungCapTheoTen(String tuKhoa) throws SQLException` | public |
| `public Supplier4 layThongTinNhaCungCap(int id) throws SQLException` | public |
| `public int themNhaCungCap(Supplier4 supplier) throws SQLException, ValidationException4` | public |
| `private Supplier4 mapSupplier(ResultSet rs) throws SQLException` | private |

## dao/WarehouseStaffDAO4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public WarehouseStaff4 layThongTinNhanVienKho(int id) throws SQLException` | public |

## dto/SessionUser4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public static SessionUser4 fromMember(Member4 member)` | public |
| `public int getId()` | public |
| `public String getHoTen()` | public |
| `public String getVaiTro()` | public |
| `public String getViTri()` | public |

## exception/ValidationException4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public String getField()` | public |

## filter/AuthFilter4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init(FilterConfig filterConfig) throws ServletException` | public |
| `public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException` | public |
| `public void destroy()` | public |

## filter/EncodingFilter4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public void init(FilterConfig filterConfig) throws ServletException` | public |
| `public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException` | public |
| `public void destroy()` | public |

## model/Employee4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public String getViTri()` | public |
| `public void setViTri(String viTri)` | public |
| `public String getTrangThaiLamViec()` | public |
| `public void setTrangThaiLamViec(String trangThaiLamViec)` | public |

## model/Member4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getHoTen()` | public |
| `public void setHoTen(String hoTen)` | public |
| `public String getTenDangNhap()` | public |
| `public void setTenDangNhap(String tenDangNhap)` | public |
| `public String getMatKhau()` | public |
| `public void setMatKhau(String matKhau)` | public |
| `public LocalDate getNgaySinh()` | public |
| `public void setNgaySinh(LocalDate ngaySinh)` | public |
| `public String getDiaChi()` | public |
| `public void setDiaChi(String diaChi)` | public |
| `public String getEmail()` | public |
| `public void setEmail(String email)` | public |
| `public String getDienThoai()` | public |
| `public void setDienThoai(String dienThoai)` | public |
| `public String getVaiTro()` | public |
| `public void setVaiTro(String vaiTro)` | public |
| `public String getTrangThaiTaiKhoan()` | public |
| `public void setTrangThaiTaiKhoan(String trangThaiTaiKhoan)` | public |

## model/PurchaseInvoice4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public BigDecimal tinhTongTien()` | public |
| `public BigDecimal getTongTien()` | public |
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getMaYeuCau()` | public |
| `public void setMaYeuCau(String maYeuCau)` | public |
| `public LocalDateTime getNgayNhap()` | public |
| `public void setNgayNhap(LocalDateTime ngayNhap)` | public |
| `public LocalDateTime getThoiDiemXacNhan()` | public |
| `public void setThoiDiemXacNhan(LocalDateTime thoiDiemXacNhan)` | public |
| `public String getTinhTrang()` | public |
| `public void setTinhTrang(String tinhTrang)` | public |
| `public LocalDateTime getThoiDiemThanhToan()` | public |
| `public void setThoiDiemThanhToan(LocalDateTime thoiDiemThanhToan)` | public |
| `public Supplier4 getNhaCungCap()` | public |
| `public void setNhaCungCap(Supplier4 nhaCungCap)` | public |
| `public WarehouseStaff4 getNhanVienKho()` | public |
| `public void setNhanVienKho(WarehouseStaff4 nhanVienKho)` | public |
| `public List<PurchaseInvoiceDetail4> getDsChiTietNhap()` | public |
| `public void setDsChiTietNhap(List<PurchaseInvoiceDetail4> dsChiTietNhap)` | public |
| `public String getNhaCungCapTenApDung()` | public |
| `public void setNhaCungCapTenApDung(String nhaCungCapTenApDung)` | public |
| `public String getNhanVienTenApDung()` | public |
| `public void setNhanVienTenApDung(String nhanVienTenApDung)` | public |

## model/PurchaseInvoiceDetail4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public BigDecimal tinhThanhTien()` | public |
| `public BigDecimal getThanhTien()` | public |
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public BigDecimal getSoLuong()` | public |
| `public void setSoLuong(BigDecimal soLuong)` | public |
| `public BigDecimal getDonGiaNhap()` | public |
| `public void setDonGiaNhap(BigDecimal donGiaNhap)` | public |
| `public String getTenPhuTungApDung()` | public |
| `public void setTenPhuTungApDung(String tenPhuTungApDung)` | public |
| `public String getDonViApDung()` | public |
| `public void setDonViApDung(String donViApDung)` | public |
| `public SparePart4 getPhuTung()` | public |
| `public void setPhuTung(SparePart4 phuTung)` | public |

## model/Service4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getTen()` | public |
| `public void setTen(String ten)` | public |
| `public String getNhom()` | public |
| `public void setNhom(String nhom)` | public |
| `public String getMoTa()` | public |
| `public void setMoTa(String moTa)` | public |
| `public String getNoiDung()` | public |
| `public void setNoiDung(String noiDung)` | public |
| `public String getHinhAnh()` | public |
| `public void setHinhAnh(String hinhAnh)` | public |
| `public BigDecimal getDonGia()` | public |
| `public void setDonGia(BigDecimal donGia)` | public |
| `public int getThoiGianDuKien()` | public |
| `public void setThoiGianDuKien(int thoiGianDuKien)` | public |
| `public String getHanBaoHanh()` | public |
| `public void setHanBaoHanh(String hanBaoHanh)` | public |
| `public String getDieuKienBaoHanh()` | public |
| `public void setDieuKienBaoHanh(String dieuKienBaoHanh)` | public |
| `public String getTrangThai()` | public |
| `public void setTrangThai(String trangThai)` | public |

## model/SparePart4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getTen()` | public |
| `public void setTen(String ten)` | public |
| `public String getMoTa()` | public |
| `public void setMoTa(String moTa)` | public |
| `public String getHinhAnh()` | public |
| `public void setHinhAnh(String hinhAnh)` | public |
| `public String getDonVi()` | public |
| `public void setDonVi(String donVi)` | public |
| `public String getHangSanXuat()` | public |
| `public void setHangSanXuat(String hangSanXuat)` | public |
| `public String getThongSo()` | public |
| `public void setThongSo(String thongSo)` | public |
| `public String getDongXePhuHop()` | public |
| `public void setDongXePhuHop(String dongXePhuHop)` | public |
| `public BigDecimal getGiaBan()` | public |
| `public void setGiaBan(BigDecimal giaBan)` | public |
| `public String getHanBaoHanh()` | public |
| `public void setHanBaoHanh(String hanBaoHanh)` | public |
| `public String getDieuKienBaoHanh()` | public |
| `public void setDieuKienBaoHanh(String dieuKienBaoHanh)` | public |
| `public String getTrangThai()` | public |
| `public void setTrangThai(String trangThai)` | public |
| `public BigDecimal getTonKho()` | public |
| `public void setTonKho(BigDecimal tonKho)` | public |
| `public SparePartCategory4 getNhom()` | public |
| `public void setNhom(SparePartCategory4 nhom)` | public |

## model/SparePartCategory4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getTen()` | public |
| `public void setTen(String ten)` | public |
| `public String getMoTa()` | public |
| `public void setMoTa(String moTa)` | public |
| `public String getTrangThai()` | public |
| `public void setTrangThai(String trangThai)` | public |

## model/Supplier4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public int getId()` | public |
| `public void setId(int id)` | public |
| `public String getTen()` | public |
| `public void setTen(String ten)` | public |
| `public String getDiaChi()` | public |
| `public void setDiaChi(String diaChi)` | public |
| `public String getDienThoai()` | public |
| `public void setDienThoai(String dienThoai)` | public |
| `public String getEmail()` | public |
| `public void setEmail(String email)` | public |
| `public String getTrangThai()` | public |
| `public void setTrangThai(String trangThai)` | public |

## util/DraftStore4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `private static void kiemTraCuPhapMaYeuCau(String maYeuCau) throws ValidationException4` | private |
| `private static Map<String, PurchaseInvoice4> getDraftMap(HttpSession session)` | private |
| `private static Map<String, Long> getVersionMap(HttpSession session)` | private |
| `private static Set<String> getConfirmingSet(HttpSession session)` | private |
| `private static Map<String, Map<String, String>> getFormValuesMap(HttpSession session)` | private |
| `public static void kiemTraGioiHan(HttpSession session) throws ValidationException4` | public |
| `public static PurchaseInvoice4 taoBanNhap(HttpSession session, Supplier4 supplier, WarehouseStaff4 staff) throws ValidationException4` | public |
| `public static PurchaseInvoice4 layBanNhap(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static void luuBanNhap(HttpSession session, PurchaseInvoice4 draft) throws ValidationException4` | public |
| `public static void xoaBanNhap(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static long layPhienBan(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static void kiemTraPhienBan(HttpSession session, String maYeuCau, long phienBan) throws ValidationException4` | public |
| `public static long tangPhienBan(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static PurchaseInvoice4 batDauXacNhan(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static PurchaseInvoice4 batDauXacNhan(HttpSession session, String maYeuCau, long phienBan) throws ValidationException4` | public |
| `public static void ketThucXacNhan(HttpSession session, String maYeuCau)` | public |
| `public static Map<String, String> layGiaTriForm(HttpSession session, String maYeuCau) throws ValidationException4` | public |
| `public static Map<String, String> layDuLieuFormNhap(HttpSession session, String maYeuCau)` | public |
| `public static void luuGiaTriForm(HttpSession session, String maYeuCau, Map<String, String> values) throws ValidationException4` | public |
| `public static void capNhatDuLieuFormNhap(HttpSession session, String maYeuCau, Map<String, String> values) throws ValidationException4` | public |
| `public static void xoaLoiCuaPhuTung(HttpSession session, String maYeuCau, int partId) throws ValidationException4` | public |
| `public static PurchaseInvoice4 saoChep(PurchaseInvoice4 draft)` | public |

## util/PasswordUtil4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public static String bamMatKhau(char[] matKhau)` | public |
| `public static boolean kiemTraMatKhau(String matKhau, String hashDaLuu)` | public |
| `public static boolean verifyPassword(String matKhau, String hashDaLuu)` | public |
| `public static boolean kiemTraMatKhau(char[] matKhau, String hashDaLuu)` | public |
| `public static void main(String[] args)` | public |

## util/Validation4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public static String batBuoc(String value, String field, int maxLength) throws ValidationException4` | public |
| `public static String tuyChon(String value, int maxLength) throws ValidationException4` | public |
| `public static int idDuong(String value, String field) throws ValidationException4` | public |
| `public static BigDecimal soThapPhan(String value, String field, int precision, int scale, boolean choPhepKhong) throws ValidationException4` | public |
| `public static void kiemTraSoLuong(BigDecimal qty, String donVi) throws ValidationException4` | public |
| `public static void kiemTraEmail(String email) throws ValidationException4` | public |
| `public static void kiemTraDienThoai(String phone) throws ValidationException4` | public |
| `public static void kiemTraNhaCungCap(Supplier4 supplier) throws ValidationException4` | public |
| `public static void kiemTraPhuTung(SparePart4 part) throws ValidationException4` | public |
| `public static void kiemTraHoaDonNhap(PurchaseInvoice4 hoaDon) throws ValidationException4` | public |

## util/WebUtil4.java

| Hàm hiện có (chữ ký Java) | Phạm vi |
|---|---|
| `public static void forward(HttpServletRequest req, HttpServletResponse res, String view) throws ServletException, IOException` | public |
| `public static void redirect(HttpServletRequest req, HttpServletResponse res, String path) throws IOException` | public |
| `public static SessionUser4 requireUser(HttpServletRequest req) throws ValidationException4` | public |
| `public static String taoCsrfToken(HttpSession session)` | public |
| `public static boolean hopLeCsrf(HttpServletRequest req)` | public |
| `public static void flash(HttpServletRequest req, String message)` | public |
| `public static void datFlash(HttpServletRequest req, String message)` | public |
| `public static String layFlash(HttpServletRequest req)` | public |
| `public static String dinhDangThoiDiem(LocalDateTime value)` | public |

## Quy tắc đối chiếu

- `kiemTraVersionVaDongThoi` là hàm riêng trả boolean: thiếu/sai version bị 400, version cũ hoặc đang xác nhận bị 409; sai người lập bị 403.
- `luuDuLieuDongVaoDraft` là hàm riêng giữ raw input/lỗi, ghi lại bản sao bằng `luuBanNhap`. Không thêm action nghiệp vụ.
- Xác nhận lấy bản sao đã lưu trong khóa session ngắn; JDBC chạy ngoài khóa. DAO kiểm tra dữ liệu gốc khi khóa và rollback cả lỗi SQL lẫn validation.
- Tên kỹ thuật đúng trong source: `Validation4.batBuoc`, `SparePartCategoryDAO4.layNhomDangSuDung`, `WebUtil4.hopLeCsrf`.
