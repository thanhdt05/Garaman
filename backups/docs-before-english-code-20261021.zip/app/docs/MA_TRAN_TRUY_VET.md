# MA TRẬN TRUY VẾT YÊU CẦU - THIẾT KẾ - MÃ NGUỒN - KIỂM THỬ (MA_TRAN_TRUY_VET.md)

Tài liệu này thiết lập ma trận truy vết hai chiều (Bidirectional Traceability Matrix) từ yêu cầu nghiệp vụ trong báo cáo phân tích (`26_B23DCCN764-full.docx`), đặc tả đề 26, qua các bước thiết kế tĩnh (4.3.1), biểu đồ lớp, kịch bản chi tiết (4.3.2), cấu trúc CSDL đến mã nguồn thực tế và các kịch bản kiểm thử (Test IDs).

---

## 1. Bảng Ma trận Truy vết Toàn diện

| Mã YC | Vị trí DOCX | Bước / Ngoại lệ | Giao diện (JSP/UI) | HTTP / Route | Controller (Servlet.method) | Tầng Dữ liệu (DAO/Model.method) | Bảng & Cột CSDL liên quan | Test ID | Hình 4.3.1 | Mã nhánh cho 4.3.2 |
|---|---|---|---|---|---|---|---|---|---|---|
| **TC-01** | Mục 1.2.1.a / Kịch bản Tra cứu | Bước 1–2: Vào trang chủ, bấm tra cứu | `gdChinhKH.jsp`, `gdTimThongTin.jsp` | GET `/customer/catalog` | `CatalogServlet4.hienThiTimKiem` | Không gọi DAO (trả trạng thái ban đầu) | Không truy xuất | C01 | TK-TC-UI, TK-TC-CLASS | SD-TC-01 |
| **TC-02** | Mục 1.2.1.a / Kịch bản Tra cứu | Bước 3–4: Nhập từ khóa, tìm kiếm | `gdTimThongTin.jsp` | GET `/customer/catalog?tuKhoa=...` | `CatalogServlet4.timKiem` | `ServiceDAO4.timDichVuTheoTen`, `SparePartDAO4.timPhuTungTheoTen(tuKhoa, true)` | `tblService4 (ten, donGia)`, `tblSparePart4 (ten, giaBan)` | C02, C03 | TK-TC-UI, TK-TC-CLASS | SD-TC-02 |
| **TC-03** | Mục 1.2.1.a / Kịch bản Tra cứu | Bước 5–6: Bấm xem chi tiết dịch vụ hoặc phụ tùng | `gdChiTietThongTin.jsp` | GET `/customer/catalog/detail?id=...&loai=...` | `CatalogServlet4.xemChiTiet` | `ServiceDAO4.layChiTietDichVu(id)`, `SparePartDAO4.layChiTietPhuTung(id, true)` | `tblService4`, `tblSparePart4`, `tblSparePartCategory4` | C04, C05 | TK-TC-UI, TK-TC-CLASS | SD-TC-03 |
| **TC-04** | Mục 1.2.1.a / Kịch bản Tra cứu | Ngoại lệ 3a (từ khóa rỗng), 4a (không thấy kết quả), quay lại | `gdTimThongTin.jsp`, `gdChiTietThongTin.jsp` | GET `/customer/catalog?tuKhoa=` | `CatalogServlet4.timKiem` | Trả thông báo lỗi hợp lệ hoặc danh sách rỗng, giữ từ khóa | `tblService4`, `tblSparePart4` | C06, C07 | TK-TC-UI, TK-TC-CLASS | SD-TC-04 |
| **NH-01** | Mục 1.2.1.b / Kịch bản Nhập | Bước 1–6: Chọn NCC, tạo phiên nhập | `gdChinhKho.jsp`, `gdChonNhaCungCap.jsp` | GET `/warehouse/suppliers`, POST `/warehouse/purchases/start` | `SupplierServlet4.timNhaCungCap`, `PurchaseInvoiceServlet4.batDauNhap` | `SupplierDAO4.timNhaCungCapTheoTen`, `SupplierDAO4.layThongTinNhaCungCap`, `WarehouseStaffDAO4.layThongTinNhanVienKho`, `DraftStore4.taoBanNhap` | `tblSupplier4 (id, ten, diaChi, dienThoai)` | P01 | TK-NH-UI, TK-NH-CLASS | SD-NH-01 |
| **NH-02** | Mục 1.2.1.b / Kịch bản Nhập | Ngoại lệ 4a: Thêm nhà cung cấp mới | `gdThemNhaCungCap.jsp` | GET `/warehouse/suppliers/new`, POST `/warehouse/suppliers/create` | `SupplierServlet4.hienThiThemNhaCungCap`, `SupplierServlet4.themNhaCungCap` | `SupplierDAO4.themNhaCungCap(ncc)` | `tblSupplier4 (ten, diaChi, dienThoai, email, trangThai)` | P01 | TK-NH-UI, TK-NH-CLASS | SD-NH-02 |
| **NH-03** | Mục 1.2.1.b / Kịch bản Nhập | Bước 7–11: Tìm phụ tùng, thêm vào bảng, sửa lượng/giá | `gdLapHoaDonNhap.jsp` (parts-picker.jspf) | POST `/warehouse/purchases/search-part`, `add-line`, `update` | `PurchaseInvoiceServlet4.timPhuTung`, `themDongNhap`, `capNhatDongNhap` | `SparePartDAO4.timPhuTungTheoTen(tuKhoa, false)`, `DraftStore4.luuBanNhap`, `PurchaseInvoice4.tinhTongTien` | `tblSparePart4 (id, ten, donVi, hangSanXuat, tonKho)` | P03, P04 | TK-NH-UI, TK-NH-CLASS | SD-NH-03 |
| **NH-04** | Mục 1.2.1.b / Kịch bản Nhập | Ngoại lệ 8a: Thêm phụ tùng mới chưa có trong kho | `gdThemPhuTung.jsp` | GET `/warehouse/parts/new`, POST `/warehouse/parts/create` | `SparePartServlet4.hienThiThemPhuTung`, `SparePartServlet4.themPhuTung` | `SparePartCategoryDAO4.layDanhSachNhom`, `SparePartDAO4.themPhuTung` | `tblSparePart4 (tonKho=0, trangThai mặc định 'Chưa công bố')` | P02 | TK-NH-UI, TK-NH-CLASS | SD-NH-04 |
| **NH-05** | Mục 1.2.1.b / Kịch bản Nhập | Ngoại lệ 9a (chọn part đã có), 11a/12b (lượng/giá sai, nháp rỗng) | `gdLapHoaDonNhap.jsp` | POST `/warehouse/purchases/add-line`, `confirm` | `PurchaseInvoiceServlet4.themDongNhap`, `PurchaseInvoiceServlet4.xacNhanHoaDon` | `Validation4.kiemTraSoLuong`, `Validation4.soThapPhan` | Không ghi DB nếu validate lỗi, giữ input thô | P04, P05 | TK-NH-UI, TK-NH-CLASS | SD-NH-05 |
| **NH-06** | Mục 1.2.1.b / Kịch bản Nhập | Bước 12–13, ngoại lệ 12c: Xác nhận hóa đơn, cộng dồn tồn kho | `gdLapHoaDonNhap.jsp` → redirect | POST `/warehouse/purchases/confirm` | `PurchaseInvoiceServlet4.xacNhanHoaDon` | `PurchaseInvoiceDAO4.luuHoaDonNhap`, `SparePartDAO4.tangTonSauNhap`, `DraftStore4.xoaBanNhap` | `tblPurchaseInvoice4 (id, maYeuCau, thoiDiemXacNhan)`, `tblPurchaseInvoiceDetail4`, `tblSparePart4 (tonKho)` | P06, P07, P08 | TK-NH-UI, TK-NH-CLASS | SD-NH-06 |
| **NH-07** | Mục 1.2.1.b / Kịch bản Nhập | Bước 14–17: Xem hóa đơn đã lưu và in chứng từ | `gdHoaDonNhapDaXacNhan.jsp`, `gdInHoaDonNhap.jsp` | GET `/warehouse/purchases/view`, GET `/warehouse/purchases/print` | `PurchaseInvoiceServlet4.xemHoaDon`, `PurchaseInvoiceServlet4.inHoaDon` | `PurchaseInvoiceDAO4.layThongTinHoaDonNhap(id)` | `tblPurchaseInvoice4`, `tblPurchaseInvoiceDetail4 (tenPhuTungApDung, donViApDung)` | P11, P14 | TK-NH-UI, TK-NH-CLASS | SD-NH-07 |
| **NH-08** | Mục 1.2.1.b / Kịch bản Nhập | Bước 18–19, 18a: Người lập thanh toán đúng tổng tiền | `gdHoaDonNhapDaXacNhan.jsp` | POST `/warehouse/purchases/pay` | `PurchaseInvoiceServlet4.ghiNhanThanhToan` | `PurchaseInvoiceDAO4.ghiNhanThanhToan(id, soTien, userId)` | `tblPurchaseInvoice4 (tinhTrang, thoiDiemThanhToan)` | P12, P13 | TK-NH-UI, TK-NH-CLASS | SD-NH-08 |
| **NH-09** | Mục 1.2.1.b / Kịch bản Nhập | Ngoại lệ 12a: Hủy lập hóa đơn trước khi xác nhận | `gdLapHoaDonNhap.jsp` | POST `/warehouse/purchases/cancel` | `PurchaseInvoiceServlet4.huyBanNhap` | `DraftStore4.xoaBanNhap(session, maYeuCau)` | Giữ nguyên dữ liệu NCC/part đã thêm, không phát sinh hóa đơn | P09 | TK-NH-UI, TK-NH-CLASS | SD-NH-09 |
| **NH-10** | Mục 1.2.1.b / Kịch bản Nhập | Ngoại lệ 18b: Mở lại danh sách chưa thanh toán | `gdChinhKho.jsp`, `gdHoaDonNhapDaXacNhan.jsp` | GET `/warehouse/purchases/unpaid` | `PurchaseInvoiceServlet4.hienThiHoaDonChuaThanhToan` | `PurchaseInvoiceDAO4.layHoaDonChuaThanhToan(userId)` | `tblPurchaseInvoice4 (tblEmployee4id, tinhTrang)` | P13 | TK-NH-UI, TK-NH-CLASS | SD-NH-10 |
| **KT-01** | Bổ sung kỹ thuật (File 02, 03, 10) | Quyền hạn, bảo vệ CSRF, chống double submit, session fixation | `gdDangNhap.jsp`, toàn bộ form POST | Toàn bộ các route POST và Filter | `AuthFilter4.doFilter`, `EncodingFilter4.doFilter`, `WebUtil4`, `DraftStore4` | Quản lý Session, Token, Version draft | `tblMember4 (matKhau hash PBKDF2)` | P10, P15, P16 | TK-NH-CLASS, TK-TC-CLASS | SD-KT-01 |

---

## 2. Danh mục Mã Test Case tương ứng

- **C01–C07 (Tra cứu danh mục)**:
  - `C01`: Mở trang tìm kiếm mặc định (chưa có từ khóa).
  - `C02`: Tìm từ khóa "lọc" trả về cả dịch vụ "Thay lọc dầu" và phụ tùng "Lọc dầu AF-01".
  - `C03`: Tìm từ khóa không dấu "loc" hoặc chữ hoa "LỌC" vẫn ra kết quả chính xác.
  - `C04`: Xem chi tiết dịch vụ: hiển thị mô tả, tiền công 120.000đ.
  - `C05`: Xem chi tiết phụ tùng: hiển thị thông số kỹ thuật, hãng AutoFilter, giá bán 150.000đ, không lộ giá nhập.
  - `C06`: Tìm kiếm với từ khóa rỗng / khoảng trắng báo lỗi hợp lệ.
  - `C07`: Tìm từ khóa không tồn tại ("xyz123") báo "Không tìm thấy kết quả phù hợp", nút quay lại giữ nguyên từ khóa.

- **P01–P16 (Nhập phụ tùng)**:
  - `P01`: Chọn nhà cung cấp có sẵn hoặc thêm mới bắt buộc tên, địa chỉ, số điện thoại.
  - `P02`: Thêm phụ tùng mới: gán nhóm đang dùng, tồn kho khởi tạo bằng 0, trạng thái Chưa công bố.
  - `P03`: Chọn phụ tùng vào hóa đơn, cập nhật số lượng 10, đơn giá 80.000đ -> thành tiền 800.000đ; giá bán danh mục không bị ảnh hưởng.
  - `P04`: Thêm nhiều dòng phụ tùng, tính đúng tổng tiền; chọn lại phụ tùng đã có thì focus dòng cũ, không thêm dòng trùng; đổi từ khóa tìm kiếm không mất các dòng đang nhập.
  - `P05`: Kiểm tra tính hợp lệ dữ liệu: chặn xác nhận nếu hóa đơn trống dòng, số lượng <= 0, đơn giá <= 0, số lượng lẻ cho đơn vị "Cái".
  - `P06`: Xử lý lỗi trong transaction: lỗi ghi 1 dòng bất kỳ thì rollback toàn bộ, không tạo hóa đơn dở dang, tồn kho không tăng.
  - `P07`: Xử lý submit trùng lặp đồng thời (cùng `maYeuCau` UUID): bảo đảm chỉ tạo 1 hóa đơn và tăng tồn 1 lần duy nhất (idempotent).
  - `P08`: Hai mã yêu cầu khác nhau nhập cùng một phụ tùng: lưu cả 2 hóa đơn hợp lệ, tồn kho tăng bằng tổng 2 lần nhập.
  - `P09`: Hủy lập hóa đơn trước khi xác nhận: xóa bản nháp, giữ nguyên nhà cung cấp và phụ tùng đã thêm mới, không ghi hóa đơn vào CSDL.
  - `P10`: Thao tác nhiều tab độc lập: mỗi tab quản lý bản nháp riêng qua `draftId`, không bị trộn lẫn dòng nhập giữa các tab.
  - `P11`: Xem và in hóa đơn: hiển thị đúng định dạng A4, in nhiều lần không làm thay đổi trạng thái thanh toán hoặc tồn kho.
  - `P12`: Người lập thanh toán hóa đơn: nhập đúng số tiền bằng tổng tiền, ghi nhận trạng thái ĐÃ THANH TOÁN và thời điểm thanh toán; tồn kho không đổi.
  - `P13`: Phân quyền thanh toán: nhân viên kho khác không thể thanh toán hóa đơn do người khác lập (HTTP 403 Forbidden); người lập đăng nhập lại thấy trong danh sách chưa thanh toán và thực hiện được.
  - `P14`: Bảo toàn snapshot lịch sử: sửa thông tin danh mục phụ tùng hoặc nhà cung cấp sau khi lập thì bản in hóa đơn cũ vẫn giữ nguyên tên và đơn vị áp dụng tại thời điểm lập.
  - `P15`: Chặn giả mạo dữ liệu: server bỏ qua các tham số tổng tiền, ngày lập, trạng thái do client cố tình gửi; kiểm tra CSRF token cho mọi form POST.
  - `P16`: Nhân viên lập ngừng làm việc: tài khoản bị khóa không đăng nhập/thanh toán được, nhưng hóa đơn lịch sử vẫn hiển thị đầy đủ tên người lập cho các nhân viên khác tra cứu.
