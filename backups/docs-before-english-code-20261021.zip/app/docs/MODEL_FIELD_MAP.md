# Bảng Ánh Xạ Thuộc Tính: Thiết Kế → Java Model → CSDL (MODEL_FIELD_MAP)

Tài liệu này đối chiếu từng thuộc tính từ mô hình lớp phân tích/thiết kế sang mã nguồn Java (`model.*`) và schema CSDL vật lý (`tbl*4`) cho đúng 10 model và 9 bảng trong phạm vi 2 module của đề 26 (`ke-hoach/00_PHAM_VI.md`).

---

## 1. Bảng ánh xạ 10 lớp model nghiệp vụ

| Tên lớp Java | Thuộc tính Java | Kiểu Java | Cột SQL / Nguồn | Kiểu SQL | Ý nghĩa & Ghi chú |
|---|---|---|---|---|---|
| **Member4** | `id` | `int` | `tblMember4.id` | `INT PK AI` | Mã định danh thành viên |
| Member4 | `hoTen` | `String` | `tblMember4.hoTen` | `VARCHAR(255)` | Họ tên đầy đủ |
| Member4 | `tenDangNhap` | `String` | `tblMember4.tenDangNhap` | `VARCHAR(100)` | Tên đăng nhập |
| Member4 | `matKhau` | `String` | `tblMember4.matKhau` | `VARCHAR(255)` | Chuỗi hash PBKDF2WithHmacSHA256 |
| Member4 | `ngaySinh` | `LocalDate` | `tblMember4.ngaySinh` | `DATE` | Ngày sinh |
| Member4 | `diaChi` | `String` | `tblMember4.diaChi` | `TEXT` | Địa chỉ |
| Member4 | `email` | `String` | `tblMember4.email` | `VARCHAR(255)` | Email |
| Member4 | `dienThoai` | `String` | `tblMember4.dienThoai` | `VARCHAR(20)` | Số điện thoại |
| Member4 | `vaiTro` | `String` | `tblMember4.vaiTro` | `VARCHAR(30)` | Vai trò ('Customer', 'WarehouseStaff') |
| Member4 | `trangThaiTaiKhoan`| `String` | `tblMember4.trangThaiTaiKhoan` | `VARCHAR(30)` | Trạng thái tài khoản |
| **Employee4** | *(kế thừa Member4)*| — | — | — | Kế thừa toàn bộ thuộc tính Member4 |
| Employee4 | `viTri` | `String` | `tblEmployee4.viTri` | `VARCHAR(30)` | Vị trí làm việc ('Kho') |
| Employee4 | `trangThaiLamViec` | `String` | `tblEmployee4.trangThaiLamViec` | `VARCHAR(30)` | Trạng thái làm việc ('Đang làm việc', 'Ngừng làm việc') |
| **WarehouseStaff4**| *(kế thừa Employee4)*| — | — | — | Lớp Java vai trò Thủ kho, dùng cho module Nhập hàng |
| **Customer4** | *(kế thừa Member4)*| — | `tblCustomer4.tblMember4id` | `INT PK` | Khóa chính tham chiếu Member4 |
| **Supplier4** | `id` | `int` | `tblSupplier4.id` | `INT PK AI` | Mã nhà cung cấp |
| Supplier4 | `ten` | `String` | `tblSupplier4.ten` | `VARCHAR(255)` | Tên nhà cung cấp |
| Supplier4 | `diaChi` | `String` | `tblSupplier4.diaChi` | `TEXT` | Địa chỉ trụ sở/kho |
| Supplier4 | `dienThoai` | `String` | `tblSupplier4.dienThoai` | `VARCHAR(20)` | Điện thoại liên hệ |
| Supplier4 | `email` | `String` | `tblSupplier4.email` | `VARCHAR(255)` | Email liên hệ |
| Supplier4 | `trangThai` | `String` | `tblSupplier4.trangThai` | `VARCHAR(30)` | Trạng thái hoạt động |
| **SparePartCategory4**| `id`| `int` | `tblSparePartCategory4.id` | `INT PK AI` | Mã nhóm phụ tùng |
| SparePartCategory4 | `ten` | `String` | `tblSparePartCategory4.ten` | `VARCHAR(255)` | Tên nhóm phụ tùng (UNIQUE) |
| SparePartCategory4 | `moTa` | `String` | `tblSparePartCategory4.moTa` | `TEXT` | Mô tả nhóm |
| SparePartCategory4 | `trangThai` | `String` | `tblSparePartCategory4.trangThai` | `VARCHAR(30)` | Trạng thái nhóm phụ tùng |
| **Service4** | `id` | `int` | `tblService4.id` | `INT PK AI` | Mã dịch vụ |
| Service4 | `ten` | `String` | `tblService4.ten` | `VARCHAR(255)` | Tên dịch vụ |
| Service4 | `nhom` | `String` | `tblService4.nhom` | `VARCHAR(255)` | Tên nhóm dịch vụ |
| Service4 | `moTa` | `String` | `tblService4.moTa` | `TEXT` | Mô tả tiền công |
| Service4 | `noiDung` | `String` | `tblService4.noiDung` | `TEXT` | Quy trình kỹ thuật thực hiện |
| Service4 | `hinhAnh` | `String` | `tblService4.hinhAnh` | `VARCHAR(255)` | Đường dẫn ảnh asset minh họa |
| Service4 | `donGia` | `BigDecimal` | `tblService4.donGia` | `DECIMAL(18,2)` | Tiền công dịch vụ |
| Service4 | `thoiGianDuKien` | `int` | `tblService4.thoiGianDuKien` | `INT` | Thời gian dự kiến (phút) |
| Service4 | `hanBaoHanh` | `String` | `tblService4.hanBaoHanh` | `VARCHAR(255)` | Hạn bảo hành dịch vụ |
| Service4 | `dieuKienBaoHanh`| `String` | `tblService4.dieuKienBaoHanh` | `TEXT` | Điều kiện bảo hành |
| Service4 | `trangThai` | `String` | `tblService4.trangThai` | `VARCHAR(30)` | Trạng thái dịch vụ |
| **SparePart4** | `id` | `int` | `tblSparePart4.id` | `INT PK AI` | Mã phụ tùng |
| SparePart4 | `ten` | `String` | `tblSparePart4.ten` | `VARCHAR(255)` | Tên phụ tùng |
| SparePart4 | `moTa` | `String` | `tblSparePart4.moTa` | `TEXT` | Mô tả phụ tùng |
| SparePart4 | `hinhAnh` | `String` | `tblSparePart4.hinhAnh` | `VARCHAR(255)` | Đường dẫn ảnh asset minh họa |
| SparePart4 | `donVi` | `String` | `tblSparePart4.donVi` | `VARCHAR(20)` | Đơn vị tính ('Cái', 'Chiếc', 'Bộ', 'Lít') |
| SparePart4 | `hangSanXuat` | `String` | `tblSparePart4.hangSanXuat` | `VARCHAR(255)` | Hãng sản xuất |
| SparePart4 | `thongSo` | `String` | `tblSparePart4.thongSo` | `TEXT` | Thông số kỹ thuật |
| SparePart4 | `dongXePhuHop` | `String` | `tblSparePart4.dongXePhuHop` | `TEXT` | Dòng xe phù hợp |
| SparePart4 | `giaBan` | `BigDecimal` | `tblSparePart4.giaBan` | `DECIMAL(18,2)` | Đơn giá bán (nullable nếu Chưa công bố) |
| SparePart4 | `hanBaoHanh` | `String` | `tblSparePart4.hanBaoHanh` | `VARCHAR(255)` | Hạn bảo hành |
| SparePart4 | `dieuKienBaoHanh`| `String` | `tblSparePart4.dieuKienBaoHanh` | `TEXT` | Điều kiện bảo hành |
| SparePart4 | `trangThai` | `String` | `tblSparePart4.trangThai` | `VARCHAR(30)` | Trạng thái kinh doanh |
| SparePart4 | `tonKho` | `BigDecimal` | `tblSparePart4.tonKho` | `DECIMAL(12,3)` | Số lượng tồn kho thực tế |
| SparePart4 | `nhom` | `SparePartCategory4` | `tblSparePartCategory4id` | `INT FK` | Nhóm phụ tùng |
| **PurchaseInvoice4**| `id`| `int` | `tblPurchaseInvoice4.id` | `INT PK AI` | Mã hóa đơn nhập |
| PurchaseInvoice4 | `ngayNhap` | `LocalDateTime`| `tblPurchaseInvoice4.ngayNhap` | `DATETIME` | Thời điểm lập hóa đơn |
| PurchaseInvoice4 | `thoiDiemXacNhan`| `LocalDateTime`| `tblPurchaseInvoice4.thoiDiemXacNhan`| `DATETIME` | Thời điểm xác nhận nhập hàng |
| PurchaseInvoice4 | `tinhTrang` | `String` | `tblPurchaseInvoice4.tinhTrang` | `VARCHAR(30)` | 'Chưa thanh toán' / 'Đã thanh toán' |
| PurchaseInvoice4 | `thoiDiemThanhToan`| `LocalDateTime`| `tblPurchaseInvoice4.thoiDiemThanhToan`| `DATETIME` | Thời điểm ghi nhận trả tiền (nullable) |
| PurchaseInvoice4 | `nhaCungCap` | `Supplier4` | `tblSupplier4id` | `INT FK` | Nhà cung cấp |
| PurchaseInvoice4 | `nhanVienKho` | `WarehouseStaff4`| `tblEmployee4id` | `INT FK` | Nhân viên kho lập & trả tiền |
| PurchaseInvoice4 | `maYeuCau` | `String` | `tblPurchaseInvoice4.maYeuCau` | `CHAR(36) UQ` | UUID sinh ở server chống lặp |
| PurchaseInvoice4 | `nhaCungCapTenApDung`| `String` | `tblPurchaseInvoice4.nhaCungCapTenApDung`| `VARCHAR(255)`| Snapshot tên NCC chốt lịch sử |
| PurchaseInvoice4 | `nhanVienTenApDung` | `String` | `tblPurchaseInvoice4.nhanVienTenApDung` | `VARCHAR(255)`| Snapshot tên thủ kho chốt lịch sử |
| PurchaseInvoice4 | `dsChiTietNhap`| `List<PurchaseInvoiceDetail4>`| *(quan hệ 1-N)* | — | Danh sách các dòng chi tiết nhập |
| PurchaseInvoice4 | `tongTien` | `BigDecimal` | *(dẫn xuất qua method)* | — | `tinhTongTien()`: Tổng tiền hóa đơn |
| **PurchaseInvoiceDetail4**| `id`| `int` | `tblPurchaseInvoiceDetail4.id` | `INT PK AI` | Mã dòng chi tiết |
| PurchaseInvoiceDetail4 | `soLuong` | `BigDecimal` | `tblPurchaseInvoiceDetail4.soLuong` | `DECIMAL(12,3)` | Số lượng nhập |
| PurchaseInvoiceDetail4 | `donGiaNhap` | `BigDecimal` | `tblPurchaseInvoiceDetail4.donGiaNhap` | `DECIMAL(18,2)` | Đơn giá nhập |
| PurchaseInvoiceDetail4 | `phuTung` | `SparePart4` | `tblSparePart4id` | `INT FK` | Phụ tùng được nhập |
| PurchaseInvoiceDetail4 | `tenPhuTungApDung`| `String` | `tblPurchaseInvoiceDetail4.tenPhuTungApDung`| `VARCHAR(255)`| Snapshot tên phụ tùng |
| PurchaseInvoiceDetail4 | `donViApDung`| `String` | `tblPurchaseInvoiceDetail4.donViApDung`| `VARCHAR(20)` | Snapshot đơn vị tính |
| PurchaseInvoiceDetail4 | `thanhTien` | `BigDecimal` | *(dẫn xuất qua method)* | — | `tinhThanhTien()`: soLuong * donGiaNhap |
