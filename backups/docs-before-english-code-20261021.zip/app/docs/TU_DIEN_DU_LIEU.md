# Từ Điển Dữ Liệu CSDL GaraMan (Đề 26)

**Hệ quản trị CSDL:** MySQL 8.4 / 8.0 (InnoDB)  
**Bảng mã:** `utf8mb4` | **Collation:** `utf8mb4_0900_ai_ci`  
**Quy ước:** Chuẩn hóa đúng 9 bảng vật lý phục vụ hai module đề 26 (Khách hàng tra cứu dịch vụ/phụ tùng; Nhân viên kho nhập phụ tùng); tên bảng và tên cột giữ nguyên camelCase kèm hậu tố 4 theo đúng thiết kế CSDL và tài liệu kế hoạch `00_PHAM_VI.md`, `03_HOP_DONG.md`.

---

## 1. Danh mục 9 bảng CSDL trong phạm vi đề 26

| STT | Tên bảng | Ý nghĩa nghiệp vụ | Ghi chú cấu trúc |
|---|---|---|---|
| 1 | `tblMember4` | Thành viên hệ thống (tài khoản, thông tin chung) | Bảng cha của Employee, Customer |
| 2 | `tblEmployee4` | Nhân viên gara (Thủ kho) | Kế thừa tblMember4, PK là FK cha |
| 3 | `tblCustomer4` | Khách hàng của gara | Kế thừa tblMember4, PK là FK cha |
| 4 | `tblSupplier4` | Nhà cung cấp phụ tùng | Đang hoạt động / Ngừng hoạt động |
| 5 | `tblSparePartCategory4` | Nhóm phụ tùng | Tên UNIQUE, Đang sử dụng / Ngừng sử dụng |
| 6 | `tblService4` | Danh mục dịch vụ bảo dưỡng / sửa chữa | Đang cung cấp / Ngừng cung cấp |
| 7 | `tblSparePart4` | Danh mục phụ tùng | Lưu cột `tonKho DECIMAL(12,3)` trực tiếp |
| 8 | `tblPurchaseInvoice4` | Hóa đơn nhập phụ tùng từ nhà cung cấp | 1 người lập kiêm trả tiền, maYeuCau UUID |
| 9 | `tblPurchaseInvoiceDetail4` | Chi tiết từng dòng phụ tùng nhập | Chốt tên/đơn vị áp dụng, số lượng, đơn giá |

---

## 2. Chi tiết cấu trúc từng bảng

### 2.1. `tblMember4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã định danh thành viên |
| `hoTen` | `VARCHAR(255)` | NOT NULL | Họ và tên đầy đủ |
| `tenDangNhap` | `VARCHAR(100)` | NULL, UNIQUE | Tên đăng nhập (Customer vãng lai có thể NULL) |
| `matKhau` | `VARCHAR(255)` | NULL | Chuỗi hash PBKDF2WithHmacSHA256 |
| `ngaySinh` | `DATE` | NULL | Ngày sinh |
| `diaChi` | `TEXT` | NULL | Địa chỉ liên hệ |
| `email` | `VARCHAR(255)` | NULL | Thư điện tử |
| `dienThoai` | `VARCHAR(20)` | NOT NULL | Số điện thoại liên hệ (8-15 ký tự) |
| `vaiTro` | `VARCHAR(30)` | NOT NULL, CHECK | 'Customer', 'WarehouseStaff' |
| `trangThaiTaiKhoan`| `VARCHAR(30)` | NULL, CHECK | 'Hoạt động', 'Đã khóa' |

*Ràng buộc bổ sung:*
- `chk_member_account`: `(tenDangNhap IS NULL AND matKhau IS NULL AND trangThaiTaiKhoan IS NULL AND vaiTro = 'Customer') OR (tenDangNhap IS NOT NULL AND matKhau IS NOT NULL AND trangThaiTaiKhoan IS NOT NULL)`

### 2.2. `tblEmployee4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `tblMember4id` | `INT` | PK, FK → tblMember4(id) | Khóa chính đồng thời là khóa ngoại kế thừa |
| `viTri` | `VARCHAR(30)` | NOT NULL, CHECK | 'Kho' |
| `trangThaiLamViec`| `VARCHAR(30)` | NOT NULL, CHECK | 'Đang làm việc', 'Ngừng làm việc' |

### 2.3. `tblCustomer4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `tblMember4id` | `INT` | PK, FK → tblMember4(id) | Khóa chính đồng thời là khóa ngoại kế thừa (Customer4) |

### 2.4. `tblSupplier4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã nhà cung cấp |
| `ten` | `VARCHAR(255)` | NOT NULL | Tên nhà cung cấp |
| `diaChi` | `TEXT` | NOT NULL | Địa chỉ trụ sở / kho NCC |
| `dienThoai` | `VARCHAR(20)` | NOT NULL | Số điện thoại liên hệ |
| `email` | `VARCHAR(255)` | NULL | Thư điện tử |
| `trangThai` | `VARCHAR(30)` | NOT NULL, CHECK | 'Đang hoạt động', 'Ngừng hoạt động' (Default: Đang hoạt động) |

### 2.5. `tblSparePartCategory4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã nhóm phụ tùng |
| `ten` | `VARCHAR(255)` | NOT NULL, UNIQUE | Tên nhóm phụ tùng |
| `moTa` | `TEXT` | NULL | Mô tả chi tiết nhóm |
| `trangThai` | `VARCHAR(30)` | NOT NULL, CHECK | 'Đang sử dụng', 'Ngừng sử dụng' (Default: Đang sử dụng) |

### 2.6. `tblService4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã dịch vụ |
| `ten` | `VARCHAR(255)` | NOT NULL | Tên dịch vụ |
| `nhom` | `VARCHAR(255)` | NOT NULL | Nhóm dịch vụ (Bảo dưỡng, Sửa chữa, Chăm sóc xe...) |
| `moTa` | `TEXT` | NOT NULL | Mô tả tóm tắt dịch vụ |
| `noiDung` | `TEXT` | NOT NULL | Chi tiết quy trình thực hiện công việc |
| `hinhAnh` | `VARCHAR(255)` | NULL | Đường dẫn file ảnh minh họa asset |
| `donGia` | `DECIMAL(18,2)`| NOT NULL, CHECK >= 0 | Tiền công dịch vụ (VNĐ) |
| `thoiGianDuKien`| `INT` | NOT NULL, CHECK > 0 | Thời gian thực hiện dự kiến (phút) |
| `hanBaoHanh` | `VARCHAR(255)` | NULL | Thời hạn bảo hành (VD: '6 tháng') |
| `dieuKienBaoHanh`| `TEXT` | NULL | Điều kiện áp dụng bảo hành |
| `trangThai` | `VARCHAR(30)` | NOT NULL, CHECK | 'Đang cung cấp', 'Ngừng cung cấp' |

### 2.7. `tblSparePart4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã phụ tùng |
| `ten` | `VARCHAR(255)` | NOT NULL | Tên phụ tùng |
| `moTa` | `TEXT` | NULL | Mô tả chi tiết phụ tùng |
| `hinhAnh` | `VARCHAR(255)` | NULL | Đường dẫn file ảnh asset minh họa |
| `donVi` | `VARCHAR(20)` | NOT NULL, CHECK | 'Cái', 'Chiếc', 'Bộ', 'Lít' |
| `hangSanXuat` | `VARCHAR(255)` | NOT NULL | Hãng sản xuất phụ tùng |
| `thongSo` | `TEXT` | NULL | Thông số kỹ thuật chi tiết |
| `dongXePhuHop` | `TEXT` | NULL | Dòng xe ô tô tương thích |
| `giaBan` | `DECIMAL(18,2)`| NULL, CHECK >= 0 | Đơn giá bán niêm yết (NULL nếu Chưa công bố) |
| `hanBaoHanh` | `VARCHAR(255)` | NULL | Thời hạn bảo hành phụ tùng |
| `dieuKienBaoHanh`| `TEXT` | NULL | Điều kiện bảo hành của hãng/gara |
| `trangThai` | `VARCHAR(30)` | NOT NULL, CHECK | 'Chưa công bố', 'Đang kinh doanh', 'Ngừng kinh doanh' |
| `tonKho` | `DECIMAL(12,3)`| NOT NULL, DEFAULT 0 | Số lượng tồn kho thực tế, lưu trực tiếp |
| `tblSparePartCategory4id` | `INT` | NOT NULL, FK → Category | Nhóm phụ tùng tương ứng |

*Ràng buộc bổ sung:*
- `chk_sparepart_kinhDoanh`: Khi `trangThai = 'Đang kinh doanh'` thì bắt buộc `giaBan IS NOT NULL` và `moTa` không được rỗng.

### 2.8. `tblPurchaseInvoice4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã hóa đơn nhập |
| `ngayNhap` | `DATETIME` | NOT NULL | Thời điểm lập hóa đơn nhập |
| `thoiDiemXacNhan`| `DATETIME` | NOT NULL | Thời điểm xác nhận nhập hàng |
| `tinhTrang` | `VARCHAR(30)` | NOT NULL, CHECK | 'Chưa thanh toán', 'Đã thanh toán' (Default: Chưa thanh toán) |
| `thoiDiemThanhToan`| `DATETIME` | NULL | Thời điểm ghi nhận trả tiền cho NCC |
| `tblSupplier4id` | `INT` | NOT NULL, FK → Supplier | Nhà cung cấp xuất hàng |
| `tblEmployee4id` | `INT` | NOT NULL, FK → Employee | Nhân viên kho thực hiện lập và thanh toán |
| `maYeuCau` | `CHAR(36)` | NOT NULL, UNIQUE | UUID sinh ở server chống trùng lặp nhập/tiền |
| `nhaCungCapTenApDung` | `VARCHAR(255)` | NOT NULL | Snapshot tên nhà cung cấp tại thời điểm xác nhận |
| `nhanVienTenApDung` | `VARCHAR(255)` | NOT NULL | Snapshot tên nhân viên kho tại thời điểm xác nhận |

*Ràng buộc bổ sung:*
- `chk_purchase_invoice_thanhToan`: `(tinhTrang = 'Chưa thanh toán' AND thoiDiemThanhToan IS NULL) OR (tinhTrang = 'Đã thanh toán' AND thoiDiemThanhToan IS NOT NULL)`

### 2.9. `tblPurchaseInvoiceDetail4`
| Cột | Kiểu dữ liệu | Ràng buộc | Ý nghĩa / Ghi chú |
|---|---|---|---|
| `id` | `INT` | PK, AUTO_INCREMENT | Mã dòng chi tiết hóa đơn nhập |
| `soLuong` | `DECIMAL(12,3)`| NOT NULL, CHECK > 0 | Số lượng nhập |
| `donGiaNhap` | `DECIMAL(18,2)`| NOT NULL, CHECK > 0 | Đơn giá nhập thỏa thuận với NCC (VNĐ) |
| `tblPurchaseInvoice4id` | `INT` | NOT NULL, FK → PurchaseInvoice | Hóa đơn nhập cha |
| `tblSparePart4id` | `INT` | NOT NULL, FK → SparePart | Phụ tùng được nhập |
| `tenPhuTungApDung` | `VARCHAR(255)`| NOT NULL | Snapshot tên phụ tùng tại thời điểm xác nhận |
| `donViApDung` | `VARCHAR(20)` | NOT NULL | Snapshot đơn vị tính tại thời điểm xác nhận |

*Ràng buộc bổ sung:*
- `uk_purchase_part`: UNIQUE (`tblPurchaseInvoice4id`, `tblSparePart4id`) - Mỗi phụ tùng chỉ xuất hiện tối đa 1 dòng trên hóa đơn nhập.
