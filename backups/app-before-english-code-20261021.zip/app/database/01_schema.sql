-- =====================================================================
-- CSDL GaraMan (Đề 26 - PTIT)
-- Schema tập con chuẩn hóa 9 bảng phục vụ đúng 2 module đề 26:
--   1. Khách hàng tra cứu dịch vụ / phụ tùng
--   2. Nhân viên kho nhập phụ tùng
-- Động cơ lưu trữ: InnoDB, Bảng mã: utf8mb4, Collation: utf8mb4_0900_ai_ci
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `garaman4`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_0900_ai_ci;

USE `garaman4`;

-- 1. Bảng thành viên chung (Member)
CREATE TABLE IF NOT EXISTS `tblMember4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `hoTen` VARCHAR(255) NOT NULL,
    `tenDangNhap` VARCHAR(100) NULL UNIQUE,
    `matKhau` VARCHAR(255) NULL,
    `ngaySinh` DATE NULL,
    `diaChi` TEXT NULL,
    `email` VARCHAR(255) NULL,
    `dienThoai` VARCHAR(20) NOT NULL,
    `vaiTro` VARCHAR(30) NOT NULL,
    `trangThaiTaiKhoan` VARCHAR(30) NULL,
    CONSTRAINT `chk_member_vaiTro` CHECK (`vaiTro` IN ('Customer', 'WarehouseStaff')),
    CONSTRAINT `chk_member_trangThai` CHECK (`trangThaiTaiKhoan` IS NULL OR `trangThaiTaiKhoan` IN ('Hoạt động', 'Đã khóa')),
    CONSTRAINT `chk_member_account` CHECK (
        (`tenDangNhap` IS NULL AND `matKhau` IS NULL AND `trangThaiTaiKhoan` IS NULL AND `vaiTro` = 'Customer')
        OR (`tenDangNhap` IS NOT NULL AND `matKhau` IS NOT NULL AND `trangThaiTaiKhoan` IS NOT NULL)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 2. Bảng nhân viên (Employee kế thừa Member)
CREATE TABLE IF NOT EXISTS `tblEmployee4` (
    `tblMember4id` INT PRIMARY KEY,
    `viTri` VARCHAR(30) NOT NULL,
    `trangThaiLamViec` VARCHAR(30) NOT NULL,
    CONSTRAINT `chk_employee_viTri` CHECK (`viTri` IN ('Kho')),
    CONSTRAINT `chk_employee_trangThai` CHECK (`trangThaiLamViec` IN ('Đang làm việc', 'Ngừng làm việc')),
    CONSTRAINT `fk_employee_member` FOREIGN KEY (`tblMember4id`) REFERENCES `tblMember4` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 3. Bảng khách hàng (Customer kế thừa Member)
CREATE TABLE IF NOT EXISTS `tblCustomer4` (
    `tblMember4id` INT PRIMARY KEY,
    CONSTRAINT `fk_customer_member` FOREIGN KEY (`tblMember4id`) REFERENCES `tblMember4` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 4. Bảng nhà cung cấp (Supplier)
CREATE TABLE IF NOT EXISTS `tblSupplier4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ten` VARCHAR(255) NOT NULL,
    `diaChi` TEXT NOT NULL,
    `dienThoai` VARCHAR(20) NOT NULL,
    `email` VARCHAR(255) NULL,
    `trangThai` VARCHAR(30) NOT NULL DEFAULT 'Đang hoạt động',
    CONSTRAINT `chk_supplier_trangThai` CHECK (`trangThai` IN ('Đang hoạt động', 'Ngừng hoạt động'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 5. Bảng nhóm phụ tùng (SparePartCategory)
CREATE TABLE IF NOT EXISTS `tblSparePartCategory4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ten` VARCHAR(255) NOT NULL UNIQUE,
    `moTa` TEXT NULL,
    `trangThai` VARCHAR(30) NOT NULL DEFAULT 'Đang sử dụng',
    CONSTRAINT `chk_category_trangThai` CHECK (`trangThai` IN ('Đang sử dụng', 'Ngừng sử dụng'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 6. Bảng dịch vụ (Service)
CREATE TABLE IF NOT EXISTS `tblService4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ten` VARCHAR(255) NOT NULL,
    `nhom` VARCHAR(255) NOT NULL,
    `moTa` TEXT NOT NULL,
    `noiDung` TEXT NOT NULL,
    `hinhAnh` VARCHAR(255) NULL,
    `donGia` DECIMAL(18,2) NOT NULL,
    `thoiGianDuKien` INT NOT NULL,
    `hanBaoHanh` VARCHAR(255) NULL,
    `dieuKienBaoHanh` TEXT NULL,
    `trangThai` VARCHAR(30) NOT NULL DEFAULT 'Đang cung cấp',
    CONSTRAINT `chk_service_donGia` CHECK (`donGia` >= 0),
    CONSTRAINT `chk_service_thoiGian` CHECK (`thoiGianDuKien` > 0),
    CONSTRAINT `chk_service_trangThai` CHECK (`trangThai` IN ('Đang cung cấp', 'Ngừng cung cấp'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 7. Bảng phụ tùng (SparePart - lưu trữ tonKho trực tiếp)
CREATE TABLE IF NOT EXISTS `tblSparePart4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ten` VARCHAR(255) NOT NULL,
    `moTa` TEXT NULL,
    `hinhAnh` VARCHAR(255) NULL,
    `donVi` VARCHAR(20) NOT NULL,
    `hangSanXuat` VARCHAR(255) NOT NULL,
    `thongSo` TEXT NULL,
    `dongXePhuHop` TEXT NULL,
    `giaBan` DECIMAL(18,2) NULL,
    `hanBaoHanh` VARCHAR(255) NULL,
    `dieuKienBaoHanh` TEXT NULL,
    `trangThai` VARCHAR(30) NOT NULL DEFAULT 'Chưa công bố',
    `tonKho` DECIMAL(12,3) NOT NULL DEFAULT 0,
    `tblSparePartCategory4id` INT NOT NULL,
    CONSTRAINT `chk_sparepart_donVi` CHECK (`donVi` IN ('Cái', 'Chiếc', 'Bộ', 'Lít')),
    CONSTRAINT `chk_sparepart_trangThai` CHECK (`trangThai` IN ('Chưa công bố', 'Đang kinh doanh', 'Ngừng kinh doanh')),
    CONSTRAINT `chk_sparepart_giaBan` CHECK (`giaBan` IS NULL OR `giaBan` >= 0),
    CONSTRAINT `chk_sparepart_tonKho` CHECK (`tonKho` >= 0),
    CONSTRAINT `chk_sparepart_kinhDoanh` CHECK (
        `trangThai` <> 'Đang kinh doanh'
        OR (`giaBan` IS NOT NULL AND `moTa` IS NOT NULL AND CHAR_LENGTH(TRIM(`moTa`)) > 0)
    ),
    CONSTRAINT `fk_sparepart_category` FOREIGN KEY (`tblSparePartCategory4id`) REFERENCES `tblSparePartCategory4` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 8. Bảng hóa đơn nhập phụ tùng (PurchaseInvoice)
CREATE TABLE IF NOT EXISTS `tblPurchaseInvoice4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ngayNhap` DATETIME NOT NULL,
    `thoiDiemXacNhan` DATETIME NOT NULL,
    `tinhTrang` VARCHAR(30) NOT NULL DEFAULT 'Chưa thanh toán',
    `thoiDiemThanhToan` DATETIME NULL,
    `tblSupplier4id` INT NOT NULL,
    `tblEmployee4id` INT NOT NULL,
    `maYeuCau` CHAR(36) NOT NULL,
    `nhaCungCapTenApDung` VARCHAR(255) NOT NULL,
    `nhanVienTenApDung` VARCHAR(255) NOT NULL,
    CONSTRAINT `uk_purchase_request` UNIQUE (`maYeuCau`),
    CONSTRAINT `chk_purchase_invoice_tinhTrang` CHECK (`tinhTrang` IN ('Chưa thanh toán', 'Đã thanh toán')),
    CONSTRAINT `chk_purchase_invoice_thanhToan` CHECK (
        (`tinhTrang` = 'Chưa thanh toán' AND `thoiDiemThanhToan` IS NULL)
        OR (`tinhTrang` = 'Đã thanh toán' AND `thoiDiemThanhToan` IS NOT NULL)
    ),
    CONSTRAINT `fk_purchase_inv_supplier` FOREIGN KEY (`tblSupplier4id`) REFERENCES `tblSupplier4` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_purchase_inv_employee` FOREIGN KEY (`tblEmployee4id`) REFERENCES `tblEmployee4` (`tblMember4id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 9. Bảng chi tiết hóa đơn nhập (PurchaseInvoiceDetail)
CREATE TABLE IF NOT EXISTS `tblPurchaseInvoiceDetail4` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `soLuong` DECIMAL(12,3) NOT NULL,
    `donGiaNhap` DECIMAL(18,2) NOT NULL,
    `tblPurchaseInvoice4id` INT NOT NULL,
    `tblSparePart4id` INT NOT NULL,
    `tenPhuTungApDung` VARCHAR(255) NOT NULL,
    `donViApDung` VARCHAR(20) NOT NULL,
    CONSTRAINT `chk_purchase_detail_soLuong` CHECK (`soLuong` > 0),
    CONSTRAINT `chk_purchase_detail_donGia` CHECK (`donGiaNhap` > 0),
    CONSTRAINT `uk_purchase_part` UNIQUE (`tblPurchaseInvoice4id`, `tblSparePart4id`),
    CONSTRAINT `fk_purchase_detail_inv` FOREIGN KEY (`tblPurchaseInvoice4id`) REFERENCES `tblPurchaseInvoice4` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_purchase_detail_part` FOREIGN KEY (`tblSparePart4id`) REFERENCES `tblSparePart4` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
