-- =====================================================================
-- Script kiểm tra tính nhất quán và toàn vẹn dữ liệu (03_verify.sql)
-- Áp dụng phạm vi 9 bảng chuẩn hóa theo 00_PHAM_VI.md và 03_HOP_DONG.md
-- Script CHỈ ĐỌC (Read-Only) đối chiếu các bất biến nghiệp vụ của 2 module
-- =====================================================================

USE `garaman4`;

-- 1. Đối chiếu tồn kho lưu trữ (tonKho) với tổng nhập thực tế từ các hóa đơn đã xác nhận
-- Trên CSDL riêng 2 module, tồn ban đầu bằng 0, tonKho phải bằng tổng nhập
SELECT 
    sp.id AS phuTungId,
    sp.ten AS tenPhuTung,
    sp.donVi,
    sp.tonKho AS tonKhoLuuTru,
    COALESCE(nhap.tongNhap, 0) AS tongLuongNhap,
    CASE 
        WHEN sp.tonKho = COALESCE(nhap.tongNhap, 0) THEN 'KHỚP'
        ELSE 'LỆCH'
    END AS ketQuaDoiChieu
FROM tblSparePart4 sp
LEFT JOIN (
    SELECT pid.tblSparePart4id, SUM(pid.soLuong) AS tongNhap
    FROM tblPurchaseInvoiceDetail4 pid
    INNER JOIN tblPurchaseInvoice4 pi ON pid.tblPurchaseInvoice4id = pi.id
    GROUP BY pid.tblSparePart4id
) nhap ON sp.id = nhap.tblSparePart4id;

-- 2. Kiểm tra tính toán tổng tiền từng hóa đơn nhập so với tổng dòng chi tiết
SELECT 
    pi.id AS hoaDonId,
    pi.maYeuCau,
    pi.tinhTrang,
    COUNT(pid.id) AS soDongChiTiet,
    SUM(ROUND(pid.soLuong * pid.donGiaNhap, 2)) AS tongTienChiTiet,
    CASE 
        WHEN COUNT(pid.id) = 0 THEN 'LỖI: HÓA ĐƠN KHÔNG CÓ DÒNG'
        ELSE 'HỢP LỆ'
    END AS trangThaiDong
FROM tblPurchaseInvoice4 pi
LEFT JOIN tblPurchaseInvoiceDetail4 pid ON pi.id = pid.tblPurchaseInvoice4id
GROUP BY pi.id, pi.maYeuCau, pi.tinhTrang;

-- 3. Kiểm tra trùng lặp mã yêu cầu (maYeuCau) trên hóa đơn nhập
SELECT 
    maYeuCau, 
    COUNT(*) AS soLuongLap
FROM tblPurchaseInvoice4
GROUP BY maYeuCau
HAVING COUNT(*) > 1;

-- 4. Kiểm tra trùng lặp phụ tùng trong cùng một hóa đơn nhập
SELECT 
    tblPurchaseInvoice4id, 
    tblSparePart4id, 
    COUNT(*) AS soLuongTrung
FROM tblPurchaseInvoiceDetail4
GROUP BY tblPurchaseInvoice4id, tblSparePart4id
HAVING COUNT(*) > 1;

-- 5. Kiểm tra tính nhất quán giữa tình trạng hóa đơn nhập và thời điểm thanh toán
SELECT 
    id AS hoaDonId,
    maYeuCau,
    tinhTrang,
    thoiDiemThanhToan,
    'LỖI: BẤT NHẤT TRẠNG THÁI THANH TOÁN' AS ghiChu
FROM tblPurchaseInvoice4
WHERE (tinhTrang = 'Chưa thanh toán' AND thoiDiemThanhToan IS NOT NULL)
   OR (tinhTrang = 'Đã thanh toán' AND thoiDiemThanhToan IS NULL);
