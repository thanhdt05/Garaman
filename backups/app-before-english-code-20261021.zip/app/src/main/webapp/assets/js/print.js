/**
 * print.js - Xử lý in và quay lại cho trang in hóa đơn nhập
 */

function inHoaDon() {
    window.print();
}

function quayLaiHoaDon(url) {
    if (url) {
        window.location.href = url;
    } else {
        window.history.back();
    }
}

window.addEventListener('afterprint', function() {
    var returnLink = document.querySelector('.invoice-actions a');
    if (returnLink) quayLaiHoaDon(returnLink.href);
});
