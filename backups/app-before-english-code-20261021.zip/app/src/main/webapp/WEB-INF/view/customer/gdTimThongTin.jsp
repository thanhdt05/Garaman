<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setLocale value="vi_VN" />
<c:set var="pageTitle" value="Tìm kiếm dịch vụ &amp; phụ tùng · GaraMan" scope="request" />
<c:set var="breadcrumb" value="Tra cứu thông tin" scope="request" />
<c:set var="activeNav" value="search" scope="request" />
<%@ include file="/WEB-INF/view/common/header.jspf" %>

<div class="page-heading">
  <div>
    <div class="eyebrow">KHÁCH HÀNG / TRA CỨU</div>
    <h1>Tìm dịch vụ &amp; phụ tùng</h1>
    <p>Nhập tên hoặc một phần tên để tìm thông tin bạn cần.</p>
  </div>
</div>

<section class="panel">
  <div class="panel-body">
    <form id="catalog-search" class="search-form" action="<c:url value='/customer/catalog'/>" method="get" novalidate>
      <div class="field">
        <label for="boLoc">Loại thông tin</label>
        <select id="boLoc" name="boLoc">
          <option value="all" ${boLoc == 'all' || empty boLoc ? 'selected' : ''}>Dịch vụ &amp; phụ tùng</option>
          <option value="service" ${boLoc == 'service' ? 'selected' : ''}>Dịch vụ</option>
          <option value="part" ${boLoc == 'part' ? 'selected' : ''}>Phụ tùng</option>
        </select>
      </div>
      <div class="field">
        <label for="tuKhoa">Tên dịch vụ / phụ tùng</label>
        <input id="tuKhoa" name="tuKhoa" placeholder="Ví dụ: lọc" maxlength="150" required
               value="<c:out value='${tuKhoa}'/>" aria-describedby="catalog-search-error" autofocus>
      </div>
      <button class="btn btn-primary" type="submit" id="btn-search">Tìm kiếm</button>
    </form>
    <c:if test="${not empty errorMessage}">
      <p class="error" id="catalog-search-error" role="alert"><c:out value="${errorMessage}"/></p>
    </c:if>
  </div>
</section>

<section class="panel">
  <c:choose>
    <c:when test="${not daTimKiem}">
      <div class="panel-head">
        <h2>Kết quả tìm kiếm</h2>
        <span class="result-count" id="result-count">Chưa tìm kiếm</span>
      </div>
      <div class="empty" id="search-initial">
        <strong>Bạn muốn tìm thông tin gì?</strong>
        Nhập tên dịch vụ hoặc phụ tùng và chọn Tìm kiếm.
      </div>
    </c:when>

    <c:otherwise>
      <c:set var="hienThiDV" value="${boLoc != 'part'}" />
      <c:set var="hienThiPT" value="${boLoc != 'service'}" />
      <c:set var="soDV" value="${(hienThiDV and not empty dsDichVu) ? dsDichVu.size() : 0}" />
      <c:set var="soPT" value="${(hienThiPT and not empty dsPhuTung) ? dsPhuTung.size() : 0}" />
      <c:set var="totalCount" value="${soDV + soPT}" />

      <div class="panel-head">
        <h2>Kết quả tìm kiếm</h2>
        <span class="result-count" id="result-count"><c:out value="${totalCount}"/> kết quả</span>
      </div>

      <c:choose>
        <c:when test="${totalCount == 0}">
          <div class="empty" id="search-empty">
            <strong>Không tìm thấy kết quả</strong>
            Thử tên khác hoặc chọn lại loại thông tin.
          </div>
        </c:when>

        <c:otherwise>
          <div class="table-wrap" id="search-results">
            <table id="catalog-table">
              <thead>
                <tr>
                  <th>Mã</th>
                  <th>Tên dịch vụ / phụ tùng</th>
                  <th>Loại</th>
                  <th class="number">Đơn giá / Giá bán</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <c:if test="${hienThiDV}">
                  <c:forEach var="dv" items="${dsDichVu}">
                    <tr data-type="service" data-key="<c:out value='${dv.ten}'/>">
                      <td class="code">DV<c:out value="${dv.id}"/></td>
                      <td>
                        <strong><c:out value="${dv.ten}"/></strong>
                        <small><c:out value="${dv.nhom}"/></small>
                      </td>
                      <td><span class="badge neutral">Dịch vụ</span></td>
                      <td class="number">
                        <fmt:formatNumber value="${dv.donGia}" type="currency" currencySymbol="₫" maxFractionDigits="2"/>
                      </td>
                      <td class="number">
                        <a class="text-link" href="<c:url value='/customer/catalog/detail'><c:param name='id' value='${dv.id}'/><c:param name='loai' value='service'/><c:param name='tuKhoa' value='${tuKhoa}'/><c:param name='boLoc' value='${boLoc}'/></c:url>">
                          Xem chi tiết →
                        </a>
                      </td>
                    </tr>
                  </c:forEach>
                </c:if>

                <c:if test="${hienThiPT}">
                  <c:forEach var="pt" items="${dsPhuTung}">
                    <tr data-type="part" data-key="<c:out value='${pt.ten}'/>">
                      <td class="code">PT<c:out value="${pt.id}"/></td>
                      <td>
                        <strong><c:out value="${pt.ten}"/></strong>
                        <small><c:out value="${pt.hangSanXuat}"/> · Đơn vị: <c:out value="${pt.donVi}"/></small>
                      </td>
                      <td><span class="badge">Phụ tùng</span></td>
                      <td class="number">
                        <c:choose>
                          <c:when test="${pt.giaBan != null}">
                            <fmt:formatNumber value="${pt.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="2"/>
                          </c:when>
                          <c:otherwise>Liên hệ</c:otherwise>
                        </c:choose>
                      </td>
                      <td class="number">
                        <a class="text-link" href="<c:url value='/customer/catalog/detail'><c:param name='id' value='${pt.id}'/><c:param name='loai' value='part'/><c:param name='tuKhoa' value='${tuKhoa}'/><c:param name='boLoc' value='${boLoc}'/></c:url>">
                          Xem chi tiết →
                        </a>
                      </td>
                    </tr>
                  </c:forEach>
                </c:if>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>

      <div class="panel-note">Chọn “Xem chi tiết” để xem thông tin và chính sách bảo hành của từng mục.</div>
    </c:otherwise>
  </c:choose>
</section>

<a class="btn btn-quiet" href="<c:url value='/home'/>">← Về trang chính</a>

<%@ include file="/WEB-INF/view/common/footer.jspf" %>
