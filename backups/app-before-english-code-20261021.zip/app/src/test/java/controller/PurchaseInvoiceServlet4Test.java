package controller;

import dao.PurchaseInvoiceDAO4;
import dao.SparePartDAO4;
import dao.SupplierDAO4;
import dao.WarehouseStaffDAO4;
import dto.SessionUser4;
import exception.ValidationException4;
import model.*;
import util.AppConstants4;
import util.DraftStore4;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import javax.servlet.http.*;
import javax.servlet.RequestDispatcher;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.jupiter.api.Assertions.*;

/** Controller regression tests with session/request doubles; no MySQL or JSP runtime. */
class PurchaseInvoiceServlet4Test {
    private HttpSession session;
    private PurchaseInvoice4 draft;
    private PurchaseInvoiceServlet4 servlet;
    private final AtomicInteger saved = new AtomicInteger();
    private PurchaseInvoice4 committed;
    private final Map<String,Object> requestAttributes = new HashMap<>();
    private String forwardedTo;
    private String redirectedTo;

    @BeforeEach void setup() throws Exception {
        Map<String,Object> values = new HashMap<>();
        session = (HttpSession) Proxy.newProxyInstance(getClass().getClassLoader(), new Class[]{HttpSession.class}, (p,m,a) -> {
            switch (m.getName()) {
                case "getAttribute": return values.get(a[0]);
                case "setAttribute": values.put((String)a[0], a[1]); return null;
                case "removeAttribute": values.remove(a[0]); return null;
                default: return defaultValue(m.getReturnType());
            }
        });
        session.setAttribute(AppConstants4.SESSION_USER, new SessionUser4(2, "Kho", "WarehouseStaff", "Kho"));
        Supplier4 supplier = new Supplier4(); supplier.setId(1);
        WarehouseStaff4 staff = new WarehouseStaff4(); staff.setId(2);
        draft = DraftStore4.taoBanNhap(session, supplier, staff);
        servlet = new PurchaseInvoiceServlet4();
        inject("sparePartDAO", new SparePartDAO4() {
            @Override public SparePart4 layChiTietPhuTung(int id, boolean published) {
                assertFalse(Thread.holdsLock(session), "JDBC lookup must stay outside session lock");
                SparePart4 part = new SparePart4(); part.setId(id); part.setTen("Lọc dầu");
                part.setDonVi("Cái"); part.setGiaBan(new BigDecimal("150000")); return part;
            }
        });
        inject("purchaseInvoiceDAO", new PurchaseInvoiceDAO4() {
            @Override public Integer timIdTheoMaYeuCau(String uuid, int author) { return saved.get() == 0 ? null : 42; }
            @Override public int luuHoaDonNhap(PurchaseInvoice4 invoice) {
                assertFalse(Thread.holdsLock(session), "Transaction must stay outside session lock");
                committed = invoice; saved.incrementAndGet(); return 42;
            }
        });
    }

    private void inject(String name, Object value) throws Exception {
        Field field = PurchaseInvoiceServlet4.class.getDeclaredField(name); field.setAccessible(true); field.set(servlet,value);
    }
    private static Object defaultValue(Class<?> type) {
        if (type == boolean.class) return false;
        if (type == int.class) return 0;
        if (type == long.class) return 0L;
        return null;
    }
    private Map<String,String[]> params() throws Exception {
        Map<String,String[]> params = new HashMap<>();
        params.put("maYeuCau", new String[]{draft.getMaYeuCau()});
        params.put("draftVersion", new String[]{String.valueOf(DraftStore4.layPhienBan(session,draft.getMaYeuCau()))});
        params.put("selectedPartId", new String[]{"1"});
        params.put("partId", new String[]{"1"});
        params.put("soLuong_1", new String[]{"10"});
        params.put("donGiaNhap_1", new String[]{"80000"});
        return params;
    }
    private HttpServletRequest request(Map<String,String[]> params) {
        return (HttpServletRequest) Proxy.newProxyInstance(getClass().getClassLoader(), new Class[]{HttpServletRequest.class}, (p,m,a) -> {
            switch (m.getName()) {
                case "getParameter": String[] v=params.get(a[0]); return v==null?null:v[0];
                case "getParameterValues": return params.get(a[0]);
                case "getSession": return session;
                case "getContextPath": return "";
                case "setAttribute": requestAttributes.put((String)a[0],a[1]); return null;
                case "getAttribute": return requestAttributes.get(a[0]);
                case "getRequestDispatcher":
                    String path = (String)a[0];
                    return (RequestDispatcher) Proxy.newProxyInstance(getClass().getClassLoader(), new Class[]{RequestDispatcher.class}, (dp,dm,da) -> {
                        if (dm.getName().equals("forward")) forwardedTo=path;
                        return null;
                    });
                default: return defaultValue(m.getReturnType());
            }
        });
    }
    private HttpServletResponse response(AtomicInteger status) {
        return (HttpServletResponse) Proxy.newProxyInstance(getClass().getClassLoader(),new Class[]{HttpServletResponse.class},(p,m,a)->{
            if (m.getName().equals("sendError")) status.set((Integer)a[0]);
            if (m.getName().equals("sendRedirect")) { status.set(302); redirectedTo=(String)a[0]; }
            return defaultValue(m.getReturnType());
        });
    }
    private void add() throws Exception { servlet.themDongNhap(request(params()),response(new AtomicInteger())); }
    private PurchaseInvoice4 current() throws Exception { return DraftStore4.layBanNhap(session,draft.getMaYeuCau()); }

    @Test void addAndUpdatePersistAndKeepSalePrice() throws Exception {
        add(); assertEquals(1,current().getDsChiTietNhap().size());
        assertEquals(0,current().getDsChiTietNhap().get(0).getSoLuong().signum());
        servlet.capNhatDongNhap(request(params()),response(new AtomicInteger()));
        assertEquals(0,new BigDecimal("800000").compareTo(current().getTongTien()));
        assertEquals(0,new BigDecimal("150000").compareTo(current().getDsChiTietNhap().get(0).getPhuTung().getGiaBan()));
    }
    @Test void duplicateSelectKeepsOneLineAndUpdatedInputs() throws Exception {
        add(); add(); assertEquals(1,current().getDsChiTietNhap().size());
        assertEquals(0,new BigDecimal("800000").compareTo(current().getTongTien()));
    }
    @Test void searchAndNewPartNavigationPreserveInput() throws Exception {
        add(); servlet.timPhuTung(request(params()),response(new AtomicInteger()));
        assertEquals(0,new BigDecimal("800000").compareTo(current().getTongTien()));
        Map<String,String[]> p=params(); p.put("dichDen",new String[]{"new-part"}); p.put("soLuong_1",new String[]{"12"});
        servlet.capNhatDongNhap(request(p),response(new AtomicInteger()));
        assertEquals(0,new BigDecimal("960000").compareTo(current().getTongTien()));
    }
    @Test void removeDropsLineAndItsErrors() throws Exception {
        add(); Map<String,String[]> p=params(); p.put("soLuong_1",new String[]{"abc"}); p.put("removePartId",new String[]{"1"});
        servlet.xoaDongNhap(request(p),response(new AtomicInteger()));
        assertTrue(current().getDsChiTietNhap().isEmpty());
        assertTrue(DraftStore4.layDuLieuFormNhap(session,draft.getMaYeuCau()).isEmpty());
    }
    @Test void blankOrInvalidInputCannotConfirmOldPositiveValues() throws Exception {
        add(); servlet.capNhatDongNhap(request(params()),response(new AtomicInteger()));
        Map<String,String[]> p=params(); p.put("soLuong_1",new String[]{""}); p.put("donGiaNhap_1",new String[]{"bad"});
        servlet.xacNhanHoaDon(request(p),response(new AtomicInteger()));
        assertEquals(0,saved.get()); assertEquals(0,current().getTongTien().signum());
        Map<String,String> raw=DraftStore4.layDuLieuFormNhap(session,draft.getMaYeuCau());
        assertEquals("",raw.get("soLuong_1")); assertEquals("bad",raw.get("donGiaNhap_1"));
        assertTrue(raw.containsKey("error_soLuong_1")); assertTrue(raw.containsKey("error_donGiaNhap_1"));
        servlet.capNhatDongNhap(request(params()),response(new AtomicInteger()));
        assertEquals(0,new BigDecimal("800000").compareTo(current().getTongTien()));
    }
    @Test void missingVersionAndStaleVersionAreRejected() throws Exception {
        Map<String,String[]> stale=params(); add(); AtomicInteger status=new AtomicInteger();
        servlet.capNhatDongNhap(request(stale),response(status)); assertEquals(409,status.get());
        Map<String,String[]> missing=params(); missing.remove("draftVersion");
        servlet.huyBanNhap(request(missing),response(status)); assertEquals(400,status.get()); assertNotNull(current());
    }
    @Test void confirmingDraftRejectsCancelAndEdit() throws Exception {
        add(); DraftStore4.batDauXacNhan(session,draft.getMaYeuCau());
        AtomicInteger status=new AtomicInteger();
        servlet.huyBanNhap(request(params()),response(status)); assertEquals(409,status.get());
        servlet.capNhatDongNhap(request(params()),response(status)); assertEquals(409,status.get());
        assertNotNull(current()); DraftStore4.ketThucXacNhan(session,draft.getMaYeuCau());
    }
    @Test void concurrentUpdatesAcceptOnlyOneSubmittedVersion() throws Exception {
        add(); Map<String,String[]> p=params(); ExecutorService pool=Executors.newFixedThreadPool(2);
        try {
            CountDownLatch ready=new CountDownLatch(2), go=new CountDownLatch(1);
            Callable<Integer> task=()->{ready.countDown(); go.await(); AtomicInteger status=new AtomicInteger(); servlet.capNhatDongNhap(request(p),response(status)); return status.get();};
            Future<Integer> first=pool.submit(task),second=pool.submit(task);
            assertTrue(ready.await(3,TimeUnit.SECONDS)); go.countDown();
            Set<Integer> statuses=new HashSet<>(Arrays.asList(first.get(3,TimeUnit.SECONDS),second.get(3,TimeUnit.SECONDS)));
            assertEquals(new HashSet<>(Arrays.asList(302,409)),statuses);
        } finally { pool.shutdownNow(); }
    }
    @Test void confirmationUsesUpdatedSnapshotAndRetryDoesNotSaveTwice() throws Exception {
        add(); Map<String,String[]> p=params();
        servlet.xacNhanHoaDon(request(p),response(new AtomicInteger()));
        assertEquals(1,saved.get()); assertEquals(0,new BigDecimal("800000").compareTo(committed.getTongTien()));
        servlet.xacNhanHoaDon(request(p),response(new AtomicInteger())); assertEquals(1,saved.get());
    }
    @Test void failedTransactionReleasesConfirmationForRetry() throws Exception {
        add(); inject("purchaseInvoiceDAO",new PurchaseInvoiceDAO4(){
            @Override public Integer timIdTheoMaYeuCau(String uuid,int author){return null;}
            @Override public int luuHoaDonNhap(PurchaseInvoice4 invoice) throws SQLException {throw new SQLException("test failure");}
        });
        servlet.xacNhanHoaDon(request(params()),response(new AtomicInteger()));
        AtomicInteger status=new AtomicInteger(); servlet.capNhatDongNhap(request(params()),response(status));
        assertEquals(302,status.get()); assertNotNull(current());
    }

    @Test void startLoadsSupplierThenWarehouseStaffBeforeCreatingDraft() throws Exception {
        List<String> calls = new ArrayList<>();
        inject("supplierDAO",new SupplierDAO4(){
            @Override public Supplier4 layThongTinNhaCungCap(int id) {
                calls.add("supplier:"+id);
                Supplier4 supplier=new Supplier4(); supplier.setId(id); supplier.setTen("Hòa Phát"); return supplier;
            }
        });
        inject("warehouseStaffDAO",new WarehouseStaffDAO4(){
            @Override public WarehouseStaff4 layThongTinNhanVienKho(int id) {
                calls.add("staff:"+id);
                WarehouseStaff4 staff=new WarehouseStaff4(); staff.setId(id); staff.setHoTen("Tên từ CSDL"); return staff;
            }
        });
        Map<String,String[]> p=new HashMap<>(); p.put("supplierId",new String[]{"1"});
        servlet.batDauNhap(request(p),response(new AtomicInteger()));
        assertEquals(List.of("supplier:1","staff:2"),calls);
        String uuid=redirectedTo.substring(redirectedTo.indexOf("maYeuCau=")+"maYeuCau=".length());
        PurchaseInvoice4 started=DraftStore4.layBanNhap(session,uuid);
        assertEquals("Tên từ CSDL",started.getNhanVienKho().getHoTen());
        assertEquals("Hòa Phát",started.getNhaCungCap().getTen());
        assertTrue(started.getDsChiTietNhap().isEmpty());
        assertEquals(0,started.getTongTien().signum());
    }

    @Test void missingWarehouseStaffDoesNotCreateAnIncompleteDraft() throws Exception {
        inject("supplierDAO",new SupplierDAO4(){
            @Override public Supplier4 layThongTinNhaCungCap(int id) { Supplier4 supplier=new Supplier4(); supplier.setId(id); return supplier; }
        });
        inject("warehouseStaffDAO",new WarehouseStaffDAO4(){
            @Override public WarehouseStaff4 layThongTinNhanVienKho(int id) { return null; }
        });
        int before=((Map<?,?>)session.getAttribute(AppConstants4.SESSION_PURCHASE_DRAFTS)).size();
        Map<String,String[]> p=new HashMap<>(); p.put("supplierId",new String[]{"1"});
        servlet.batDauNhap(request(p),response(new AtomicInteger()));
        assertEquals("/warehouse/suppliers",redirectedTo);
        assertEquals(before,((Map<?,?>)session.getAttribute(AppConstants4.SESSION_PURCHASE_DRAFTS)).size());
    }

    @Test void partSearchFailureKeepsDraftAndReportsQueryError() throws Exception {
        add(); servlet.capNhatDongNhap(request(params()),response(new AtomicInteger()));
        inject("sparePartDAO",new SparePartDAO4(){
            @Override public List<SparePart4> timPhuTungTheoTen(String keyword,boolean published) throws SQLException { throw new SQLException("test query failure"); }
        });
        Map<String,String[]> p=params(); p.put("tuKhoa",new String[]{"lọc"});
        servlet.hienThiBanNhap(request(p),response(new AtomicInteger()));
        assertEquals("/WEB-INF/view/warehouse/gdLapHoaDonNhap.jsp",forwardedTo);
        assertNotNull(requestAttributes.get("partSearchError"));
        assertEquals("lọc",requestAttributes.get("tuKhoa"));
        assertEquals(0,new BigDecimal("800000").compareTo(((PurchaseInvoice4)requestAttributes.get("hoaDonNhap")).getTongTien()));
    }

    @Test void paymentErrorsStayOnConfirmedInvoiceAndKeepEnteredAmount() throws Exception {
        add(); servlet.capNhatDongNhap(request(params()),response(new AtomicInteger()));
        PurchaseInvoice4 invoice=current(); invoice.setId(42);
        AtomicInteger attempts=new AtomicInteger();
        inject("purchaseInvoiceDAO",new PurchaseInvoiceDAO4(){
            @Override public PurchaseInvoice4 layThongTinHoaDonNhap(int id) { return invoice; }
            @Override public boolean ghiNhanThanhToan(int id,BigDecimal amount,int author) throws ValidationException4 {
                attempts.incrementAndGet();
                throw new ValidationException4("soTienDaTra","Số tiền không khớp tổng hóa đơn");
            }
        });
        for (String raw:List.of("","0","799999","800001")) {
            Map<String,String[]> p=new HashMap<>(); p.put("id",new String[]{"42"}); p.put("soTienDaTra",new String[]{raw});
            AtomicInteger status=new AtomicInteger();
            servlet.ghiNhanThanhToan(request(p),response(status));
            assertEquals(0,status.get(),"Lỗi số tiền phải hiển thị tại hóa đơn, không trả trang lỗi");
            assertEquals("/WEB-INF/view/warehouse/gdHoaDonNhapDaXacNhan.jsp",forwardedTo);
            assertEquals(raw,((Map<?,?>)requestAttributes.get("formValues")).get("soTienDaTra"));
            assertNotNull(requestAttributes.get("errorMessage"));
            assertEquals("Chưa thanh toán",invoice.getTinhTrang());
        }
        assertEquals(2,attempts.get(),"Giá trị rỗng/0 phải bị chặn trước DAO");
    }

    @Test void exactPaymentRedirectsToTheSameInvoice() throws Exception {
        inject("purchaseInvoiceDAO",new PurchaseInvoiceDAO4(){
            @Override public boolean ghiNhanThanhToan(int id,BigDecimal amount,int author) {
                assertEquals(42,id); assertEquals(2,author);
                assertEquals(0,new BigDecimal("800000").compareTo(amount)); return true;
            }
        });
        Map<String,String[]> p=new HashMap<>(); p.put("id",new String[]{"42"}); p.put("soTienDaTra",new String[]{"800000.00"});
        AtomicInteger status=new AtomicInteger();
        servlet.ghiNhanThanhToan(request(p),response(status));
        assertEquals(302,status.get()); assertEquals("/warehouse/purchases/view?id=42",redirectedTo);
    }
}
